#ifndef _ASM_X86_TYPES_H
#define _ASM_X86_TYPES_H

#define dma_addr_t	dma_addr_t

#include <asm-generic/types.h>


#endif /* _ASM_X86_TYPES_H */
