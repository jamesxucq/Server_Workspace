#include "StdAfx.h"
#include "CommonUtility.h"

#include "../../clientcom/utility/ulog.h"
#include "../Logger.h"
#include "Sha1.h"
#include "ChksList.h"
#include "RiverFolder.h"
#include "FilesRiver.h"

#pragma comment(lib, "..\\third party\\dbz\\dbz.lib")

CFilesRiver::CFilesRiver(void):
    m_hFilesRiver(INVALID_HANDLE_VALUE)
{
    MKZERO(m_szFilesRiver);
}

CFilesRiver::~CFilesRiver(void)
{
}

CFilesRiver objFilesRiver;

DWORD CFilesRiver::Initialize(const TCHAR *szLocation)
{
    CommonUtility::get_name(m_szFilesRiver, szLocation, FILES_RIVER_DEFAULT);
    m_hFilesRiver = CreateFile( m_szFilesRiver,
                                GENERIC_WRITE | GENERIC_READ,
                                NULL, /* FILE_SHARE_READ */
                                NULL,
                                OPEN_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
                                NULL);
    if( INVALID_HANDLE_VALUE == m_hFilesRiver ) {
        _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
        _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
        return ((DWORD)-1);
    }
    //
    // open the database
    TCHAR szFileIsonym[MAX_PATH];
    char fileName[MAX_PATH];
    CommonUtility::get_name(szFileIsonym, szLocation, FILES_ISONYM_DEFAULT);
    CommonUtility::unicode_ansi(fileName, szFileIsonym);
    // open the database
    if (!rivdb.open(fileName, TreeDB::OWRITER | TreeDB::OCREATE)) {
        // cerr << "open error: " << rivdb.error().name() << endl;
        _LOG_WARN( _T("open rivdb error."));
    }
    //
    return 0x00;
}

DWORD CFilesRiver::Finalize()
{
    // close the database
    if (!rivdb.close()) {
        // cerr << "close error: " << rivdb.error().name() << endl;
        _LOG_WARN( _T("close rivdb error."));
    }
    //
    if(INVALID_HANDLE_VALUE != m_hFilesRiver) {
        CloseHandle( m_hFilesRiver );
        m_hFilesRiver = INVALID_HANDLE_VALUE;
    }
    //
    return 0x00;
}

ULONG CFilesRiver::InsEntry(const TCHAR *szFileName, struct FileID *pFileID, ULONG lParentInde, ULONG lSibliInde)
{
    ULONG lListHinde = INVA_INDE_VALU;
    DWORD iListLength = 0;
    ULONG lFileInde = EntryUtility::FindIdleEntry(&lListHinde, &iListLength, m_hFilesRiver);
    //
    struct FileEntry tFileEntry;
    INIT_FILE_ENTRY(tFileEntry)
    _tcscpy_s(tFileEntry.szFileName, szFileName);
    tFileEntry.parent = lParentInde;
    tFileEntry.sibling = lSibliInde;
    //
    DWORD key_len = _tcslen(tFileEntry.szFileName) << 1;
    ULONG value;
    //
    // retrieve a record
    if (0 < rivdb.get((const char *)tFileEntry.szFileName, key_len, (char *)&value, sizeof(ULONG))) {
        tFileEntry.isonym_nod = value;
    }
    // store records
    if (!rivdb.set((const char *)tFileEntry.szFileName, key_len, (char *)&lFileInde, sizeof(ULONG))) {
        return INVA_INDE_VALU;
    }
    //
    tFileEntry.ftLastWrite = pFileID->ftLastWrite;
    memcpy(tFileEntry.szFileChks, pFileID->szFileChks, SHA1_DIGEST_LEN);
    tFileEntry.list_hinde = objChksList.InsEntryList(pFileID->hRiveChks, lListHinde, &iListLength, &pFileID->ftLastWrite);
    tFileEntry.chkslen = iListLength;
    if(INVA_INDE_VALU == EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lFileInde))
        return INVA_INDE_VALU;

    //
    return lFileInde;
}

ULONG CFilesRiver::InsEntry(ULONG *lListInde, DWORD iFileLength, const TCHAR *szFileName, ULONG lParentInde, ULONG lSibliInde)
{
    ULONG lListHinde = INVA_INDE_VALU;
    DWORD iListLength = 0;
    ULONG lFileInde = EntryUtility::FindIdleEntry(&lListHinde, &iListLength, m_hFilesRiver);
    //
    struct FileEntry tFileEntry;
    INIT_FILE_ENTRY(tFileEntry)
    _tcscpy_s(tFileEntry.szFileName, szFileName);
    tFileEntry.parent = lParentInde;
    tFileEntry.sibling = lSibliInde;
    //
    DWORD key_len = _tcslen(tFileEntry.szFileName) << 1;
    ULONG value;
    //
    // retrieve a record
    if (0 < rivdb.get((const char *)tFileEntry.szFileName, key_len, (char *)&value, sizeof(ULONG))) {
        tFileEntry.isonym_nod = value;
    }
    // store records
    if (!rivdb.set((const char *)tFileEntry.szFileName, key_len, (char *)&lFileInde, sizeof(ULONG))) {
        return INVA_INDE_VALU;
    }
    //
	tFileEntry.list_hinde = objChksList.FillEntryList(lListHinde, &iListLength, iFileLength);
    if(lListInde) *lListInde = tFileEntry.list_hinde;
    tFileEntry.chkslen = iListLength;
    if(INVA_INDE_VALU == EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lFileInde))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}



ULONG CFilesRiver::DelFileEntry(ULONG *lNextInde, const TCHAR *szFileName, ULONG lSibliInde)
{
    struct FileEntry tFileEntry;
    ULONG lFileInde, lIsonymInde, lPrevInde = INVA_INDE_VALU;
    //
    lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lSibliInde);
    while (_tcscmp(tFileEntry.szFileName, szFileName) && INVA_INDE_VALU!=lFileInde) {
        lPrevInde = lFileInde;
        lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.sibling);
    }
    if(INVA_INDE_VALU != lPrevInde)
        EntryUtility::ModifyNode(m_hFilesRiver, lPrevInde, FILE_INDEX_SIBLING, tFileEntry.sibling);
    //
    *lNextInde = tFileEntry.sibling;
    //
    DWORD key_len = _tcslen(szFileName) << 1;
    ULONG value;
    // retrieve a record
    if(0 < rivdb.get((const char *)szFileName, key_len, (char *)&value, sizeof(ULONG))) {
        lPrevInde = INVA_INDE_VALU;
        lIsonymInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, (DWORD)value);
        while (lFileInde!=lIsonymInde && INVA_INDE_VALU!=lIsonymInde) {
            lPrevInde = lIsonymInde;
            lIsonymInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.isonym_nod);
        }
        if(INVA_INDE_VALU == lPrevInde) {
            // store records
            if(!rivdb.set((const char *)tFileEntry.szFileName, key_len, (char *)&tFileEntry.isonym_nod, sizeof(ULONG))) {
                return ((DWORD)-1);
            }
        } else EntryUtility::ModifyNode(m_hFilesRiver, lPrevInde, FILE_INDEX_ISONYM, tFileEntry.isonym_nod);
    }
    //
    EntryUtility::AddIdleEntry(m_hFilesRiver, lFileInde);
    //
    return lFileInde;
}

static ULONG RebuildEntry(const TCHAR *szFileName, TreeDB *pdb, ULONG lFileInde)
{
    ULONG lIsonymInde = INVA_INDE_VALU;
    //
    DWORD key_len = _tcslen(szFileName) << 1;
    ULONG value;
    //
    // retrieve a record
    if(0 < pdb->get((const char *)szFileName, key_len, (char *)&value, sizeof(ULONG))) {
        lIsonymInde = value;
    }
    // store records
    if(!pdb->set((const char *)szFileName, key_len, (char *)&lFileInde, sizeof(ULONG))) {
        return INVA_INDE_VALU;
    }
    //
    return lIsonymInde;
}

ULONG CFilesRiver::EntryRestore(const TCHAR *szFileName, ULONG lParentInde, ULONG lSibliInde, const TCHAR *szRestoreName)
{
    struct FileEntry tFillEntry, tFileEntry;
    ULONG lIdleInde;
    DWORD slen, wlen;
    //
    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    if(!ReadFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    lIdleInde = tFillEntry.recycled;
    if(INVA_INDE_VALU == EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lIdleInde))
        return INVA_INDE_VALU;
    //
    if(!_tcscmp(tFileEntry.szFileName, szFileName)) {
        //
        tFillEntry.recycled = tFileEntry.recycled;
        OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
        OverLapped.Offset = lIdleOffset;
        if(!WriteFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
            return INVA_INDE_VALU;
        //
        tFileEntry.isonym_nod = RebuildEntry(szFileName, &rivdb, lIdleInde);
        tFileEntry.parent = lParentInde;
        tFileEntry.sibling = lSibliInde;
        CommonUtility::FileLastWrite(&tFileEntry.ftLastWrite, szRestoreName);

        if(INVA_INDE_VALU == EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lIdleInde))
            return INVA_INDE_VALU;
        //
    } else lIdleInde = INVA_INDE_VALU;
    //
    return lIdleInde;
}


ULONG CFilesRiver::EntryRestore(const TCHAR *szFileName, ULONG lParentInde, ULONG lSibliInde, struct FileID *pFileID)
{
    struct FileEntry tFillEntry, tFileEntry;
    ULONG lIdleInde;
    DWORD slen, wlen;
    //
    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    if(!ReadFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    lIdleInde = tFillEntry.recycled;
    if(INVA_INDE_VALU == EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lIdleInde))
        return INVA_INDE_VALU;
    //
    if(!_tcscmp(tFileEntry.szFileName, szFileName)) {
        //
        tFillEntry.recycled = tFileEntry.recycled;
        OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
        OverLapped.Offset = lIdleOffset;
        if(!WriteFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
            return INVA_INDE_VALU;
        //
        tFileEntry.isonym_nod = RebuildEntry(szFileName, &rivdb, lIdleInde);
        tFileEntry.parent = lParentInde;
        tFileEntry.sibling = lSibliInde;
        CommonUtility::FileLastWrite(&tFileEntry.ftLastWrite, pFileID->szFileName);
        memcpy(&tFileEntry.szFileChks, pFileID->szFileChks, SHA1_DIGEST_LEN);

        if(INVA_INDE_VALU == EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lIdleInde))
            return INVA_INDE_VALU;
        //
    } else lIdleInde = INVA_INDE_VALU;
    //
    return lIdleInde;
}

ULONG CFilesRiver::ExistsEntry(ULONG *lNextInde, const TCHAR *szFileName, ULONG lSibliInde)
{
    struct FileEntry tFileEntry;
    ULONG lFileInde, lPrevInde = INVA_INDE_VALU;
    //
    lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lSibliInde);
    while ((INVA_INDE_VALU!=lFileInde) && _tcscmp(tFileEntry.szFileName, szFileName)) {
        lPrevInde = lFileInde;
        lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.sibling);
// _LOG_TRACE(_T("exists lFileInde:%X tFileEntry.szFileName:%s"), lFileInde, tFileEntry.szFileName);
    }
    if(INVA_INDE_VALU != lPrevInde)
        EntryUtility::ModifyNode(m_hFilesRiver, lPrevInde, FILE_INDEX_SIBLING, tFileEntry.sibling);
    *lNextInde = tFileEntry.sibling;
    //
    return lFileInde;
}

DWORD CFilesRiver::MoveEntry(ULONG lFileInde, ULONG lParentInde, ULONG lSibliInde, const TCHAR *szExistsFile, const TCHAR *szMoveFile)
{
    struct FileEntry tFileEntry;
	// delete exists isonym
    ULONG lIsonymInde, lPrevInde = INVA_INDE_VALU;
    DWORD key_len = _tcslen(szExistsFile) << 1;
    ULONG value;
    // retrieve a record
    if(0 < rivdb.get((const char *)szExistsFile, key_len, (char *)&value, sizeof(ULONG))) {
        lPrevInde = INVA_INDE_VALU;
        lIsonymInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, (DWORD)value);
        while (lFileInde!=lIsonymInde && INVA_INDE_VALU!=lIsonymInde) {
            lPrevInde = lIsonymInde;
            lIsonymInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.isonym_nod);
        }
        if(INVA_INDE_VALU == lPrevInde) {
            // store records
            if(!rivdb.set((const char *)szExistsFile, key_len, (char *)&tFileEntry.isonym_nod, sizeof(ULONG))) {
                return ((DWORD)-1);
            }
        } else EntryUtility::ModifyNode(m_hFilesRiver, lPrevInde, FILE_INDEX_ISONYM, tFileEntry.isonym_nod);
    }
    //
    if(INVA_INDE_VALU == EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lFileInde))
        return ((DWORD)-1);
    tFileEntry.parent = lParentInde;
    tFileEntry.sibling = lSibliInde;
	_tcscpy_s(tFileEntry.szFileName, MAX_PATH, szMoveFile);
    // insert new isonym
    key_len = _tcslen(szMoveFile) << 1;
    // ULONG value;
    // retrieve a record
    if (0 < rivdb.get((const char *)szMoveFile, key_len, (char *)&value, sizeof(ULONG))) {
        tFileEntry.isonym_nod = value;
    }
    // store records
    if (!rivdb.set((const char *)szMoveFile, key_len, (char *)&lFileInde, sizeof(ULONG))) {
        return ((DWORD)-1);
    }
	// _LOG_TRACE(_T("move entry lFileInde:%X fileName:%s"), lFileInde, szMoveFile);
    //
    if(INVA_INDE_VALU == EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lFileInde))
        return ((DWORD)-1);
//
    return 0x00;
}

static ULONG RebuildEntry(HANDLE hFilesRiver, TreeDB *pdb, ULONG lSibliInde)
{
    struct FileEntry tFileEntry;
    DWORD key_len;
    ULONG value;
    //
    ULONG lIdleInde = lSibliInde;
    while(INVA_INDE_VALU != EntryUtility::ReadNode(hFilesRiver, &tFileEntry, lIdleInde)) {
        //
        // retrieve a record
        key_len = _tcslen(tFileEntry.szFileName) << 1;
        if(0 < pdb->get((const char *)tFileEntry.szFileName, key_len, (char *)&value, sizeof(ULONG))) {
            tFileEntry.isonym_nod = value;
        }
        // store records
        if(!pdb->set((const char *)tFileEntry.szFileName, key_len, (char *)&lIdleInde, sizeof(ULONG))) {
            return ((DWORD)-1);
        }
        //
        if(INVA_INDE_VALU == EntryUtility::WriteNode(hFilesRiver, &tFileEntry, lIdleInde))
            return INVA_INDE_VALU;
        //
        lIdleInde = tFileEntry.sibling;
    }
//
    return 0x00;
}

ULONG CFilesRiver::EntryRestore(ULONG lSibliInde)
{
    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    //
    struct FileEntry tFileEntry;
    ULONG lPrevInde, lIdleInde;
    lPrevInde = lIdleInde = lIdleOffset / sizeof(struct FileEntry);
    while(INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lIdleInde)) {
        if(lSibliInde == lIdleInde) {
            EntryUtility::ModifyNode(m_hFilesRiver, lPrevInde, FILE_INDEX_RECYCLED, tFileEntry.recycled);
            RebuildEntry(m_hFilesRiver, &rivdb, lSibliInde);
            break;
        }
        lPrevInde = lIdleInde;
        lIdleInde = tFileEntry.recycled;
    }
    //
    return 0x00;
}

static DWORD IndexDelete(HANDLE hFilesRiver, TreeDB *pdb, ULONG lSibliInde)
{
    struct FileEntry tDelEntry, tFileEntry;
//
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    DWORD key_len;
    ULONG value;
    //
    ULONG lPrevInde, lIsonymInde, lDelInde = lSibliInde;
    while(INVA_INDE_VALU != EntryUtility::ReadNode(hFilesRiver, &tDelEntry, lDelInde)) {
        //
        // retrieve a record
        key_len = _tcslen(tDelEntry.szFileName) << 1;
        if(0 < pdb->get((const char *)tDelEntry.szFileName, key_len, (char *)&value, sizeof(ULONG))) {
            if(value == lDelInde) { // remove records
                if(INVA_INDE_VALU == tDelEntry.isonym_nod) {
                    if (!pdb->remove((const char *)tDelEntry.szFileName, key_len))
                        return ((DWORD)-1);
                } else {
                    if(!pdb->set((const char *)tDelEntry.szFileName, key_len, (char *)&tDelEntry.isonym_nod, sizeof(ULONG)))
                        return ((DWORD)-1);
                }
            } else {
                lPrevInde = lIsonymInde = value;
                while(INVA_INDE_VALU != EntryUtility::ReadNode(hFilesRiver, &tFileEntry, lIsonymInde)) {
                    if(lDelInde == lIsonymInde) {
                        EntryUtility::ModifyNode(hFilesRiver, lPrevInde, FILE_INDEX_ISONYM, tFileEntry.isonym_nod);
                        break;
                    }
                    //
                    lPrevInde = lIsonymInde;
                    lIsonymInde = tFileEntry.isonym_nod;
                }
            }
        }
        //
        lDelInde = tDelEntry.sibling;
    }
    //
    return 0x00;
}

DWORD CFilesRiver::DelFolderEntry(ULONG lSibliInde)
{
    struct FileEntry tFillEntry;
    ULONG lIdleInde;
    DWORD slen, wlen;
    //
    if(INVA_INDE_VALU == lSibliInde) return ((DWORD)-1);
    //
    if(IndexDelete(m_hFilesRiver, &rivdb, lSibliInde)) return ((DWORD)-1);
    //
    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!ReadFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return ((DWORD)-1);
    }
    //
    lIdleInde = tFillEntry.recycled;
    tFillEntry.recycled = lSibliInde;

    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lIdleOffset;
    if(!WriteFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return ((DWORD)-1);
    //
    EntryUtility::ModifyNode(m_hFilesRiver, lSibliInde, FILE_INDEX_RECYCLED, lIdleInde);
    //
    return 0x00;
}

TCHAR *get_md5sum_text(unsigned char *md5sum)
{
    static TCHAR chksum_str[33];
    //
    for (int i=0; i<16; i++)
        _stprintf_s(chksum_str+i*2, 33, _T("%02x"), md5sum[i]);
    chksum_str[32] = _T('\0');
    //
    return chksum_str;
}

#define DUPLI_FAILED		0
#define DUPLI_OKAY			0x00000001
#define DUPLI_MODIFY		0x00000002

static DWORD IsFileDupli(struct FileEntry *pFileEntry, struct FileID *pFileID)
{
    wchar_t szParentName[MAX_PATH], szDupName[MAX_PATH];
    DWORD dwIsDupli = DUPLI_FAILED;
    //
    objRiverFolder.FolderNameIndex(szParentName, pFileEntry->parent);
    PATH_ROOT(szDupName, pFileID->szFileName)
    _tcscpy_s(NO_ROOT(szDupName), MAX_PATH-ROOT_LENGTH, szParentName);
    if(_T('\0') != *(szDupName+0x03)) _tcscat_s(szDupName, MAX_PATH, _T("\\"));
    _tcscat_s(szDupName, MAX_PATH, pFileEntry->szFileName);
    //
    FILETIME ftLastWrite;
    unsigned __int64 qwFileSize;
    CommonUtility::FileSizeTimeExt(&qwFileSize, &ftLastWrite, szDupName);
// logger(_T("c:\\river.log"), _T("qwFileSize: %lld pFileID->qwFileSize: %lld\r\n"), qwFileSize, pFileID->qwFileSize);
    if(pFileID->qwFileSize == qwFileSize) {
        if(memcmp(&pFileEntry->ftLastWrite, &ftLastWrite, sizeof(FILETIME))) {
            // CommonUtility::file_chks(pFileEntry->szFileChks, szDupName);
            objChksList.FileSha1(pFileEntry->szFileChks, szDupName, pFileEntry->list_hinde, &pFileEntry->chkslen);
            pFileEntry->ftLastWrite = ftLastWrite;
            dwIsDupli |= DUPLI_MODIFY;
        }
        //
        if(!memcmp(pFileEntry->szFileChks, pFileID->szFileChks, SHA1_DIGEST_LEN)) dwIsDupli |= DUPLI_OKAY;
    }
    //
    return dwIsDupli;
}

ULONG CFilesRiver::FindIsonym(const TCHAR *szFileName, struct FileID *pFileID)
{
    struct FileEntry tFileEntry;
    ULONG value;
    ULONG lParentInde = INVA_INDE_VALU;
// logger(_T("c:\\river.log"), _T("file valid:%s %s\r\n"), szFileName, pFileID->szFileName);
    //
    DWORD key_len = _tcslen(szFileName) << 1;
    if(0 < rivdb.get((const char *)szFileName, key_len, (char *)&value, sizeof(ULONG))) {
// logger(_T("c:\\river.log"), _T("rivdb get key: %s value: %d\r\n"), szFileName, value);
        while (INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, value)) {
            DWORD dwIsDupli = IsFileDupli(&tFileEntry, pFileID);
// logger(_T("c:\\river.log"), _T("dwIsDupli: %d\r\n"), dwIsDupli);
            if(DUPLI_MODIFY & dwIsDupli) EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, value);
            if(DUPLI_OKAY & dwIsDupli) {
                lParentInde = tFileEntry.parent;
// logger(_T("c:\\river.log"), _T("lParentInde: %d\r\n"), lParentInde);
                break;
            }
            value = tFileEntry.isonym_nod;
        }
    }
    //
    return lParentInde;
}

ULONG CFilesRiver::FindFileEntry(const TCHAR *szFileName, ULONG lSibliInde)
{
    struct FileEntry tFileEntry;
    ULONG lFileInde;
    //
    lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lSibliInde);
    while (INVA_INDE_VALU != lFileInde) {
        // logger(_T("c:\\river.log"), _T("find file entry md5_chks :%s %s\r\n"), get_md5sum_text(tFileEntry.szFileChks), get_md5sum_text(szFileChks));
        if(!_tcscmp(tFileEntry.szFileName, szFileName)) {
            break;
        }
        lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.sibling);
    }
    //
    return lFileInde;
}

ULONG CFilesRiver::FindFileEntry(const TCHAR *szFileName, ULONG lSibliInde, unsigned char *szFileChks)
{
    struct FileEntry tFileEntry;
    ULONG lFileInde;
    //
    lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lSibliInde);
    while (INVA_INDE_VALU != lFileInde) {
        // logger(_T("c:\\river.log"), _T("find file entry md5_chks :%s %s\r\n"), get_md5sum_text(tFileEntry.szFileChks), get_md5sum_text(szFileChks));
        if(!_tcscmp(tFileEntry.szFileName, szFileName)) {
            if(memcmp(&tFileEntry.szFileChks, szFileChks, SHA1_DIGEST_LEN)) lFileInde = INVA_INDE_VALU;
            break;
        }
        lFileInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.sibling);
    }
    //
    return lFileInde;
}

ULONG CFilesRiver::FindRecycled(BOOL *bPassValid, const TCHAR *szFileName, unsigned char *szFileChks)
{
    struct FileEntry tFillEntry;
    DWORD slen;
    ULONG lParentInde = INVA_INDE_VALU;

    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    if(!ReadFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    if(INVA_INDE_VALU != tFillEntry.recycled) {
        if(INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFillEntry, tFillEntry.recycled)) {
            if(!_tcscmp(tFillEntry.szFileName, szFileName)) {
                lParentInde = tFillEntry.parent;
// logger(_T("c:\\river.log"), _T("find recycled md5_chks :%s %s\r\n"), get_md5sum_text(tFillEntry.szFileChks), get_md5sum_text(szFileChks));
                if(memcmp(&tFillEntry.szFileChks, szFileChks, SHA1_DIGEST_LEN)) *bPassValid = FALSE;
                else *bPassValid = TRUE;
            }
        }
    }
    //
    return lParentInde;
}

DWORD CFilesRiver::VoidRecycled()
{
    struct FileEntry tFillEntry;
    DWORD slen;
    //
    ULONG lIdleOffset = SetFilePointer(m_hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!ReadFile(m_hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return ((DWORD)-1);
    }
    //
    if(INVA_INDE_VALU != tFillEntry.recycled)
        EntryUtility::VoidNode(m_hFilesRiver, tFillEntry.recycled);
    //
    return 0x00;
}

ULONG CFilesRiver::FindFileEntry(ULONG *lListInde, DWORD *iListLength, const TCHAR *szFileName, ULONG lSibliInde)
{
    struct FileEntry tFileEntry;
    ULONG lFindInde;
    //
    for(lFindInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lSibliInde);
            _tcscmp(tFileEntry.szFileName, szFileName) && INVA_INDE_VALU!=lFindInde;
            lFindInde = EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, tFileEntry.sibling));
    if(INVA_INDE_VALU != lFindInde) {
        *lListInde = tFileEntry.list_hinde;
        *iListLength = tFileEntry.chkslen;
    }
    //
    return lFindInde;
}

ULONG CFilesRiver::FileChklenUpdate(ULONG lFileInde, DWORD iListLength)
{
    struct FileEntry tFileEntry;
    _LOG_TRACE(_T("update chks length!"));
    if(INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lFileInde)) {
        tFileEntry.chkslen = iListLength;
        EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lFileInde);
    }
    return lFileInde;
}

DWORD CFilesRiver::ValidFileSha1(unsigned char *szSha1Chks, FILETIME *ftLastWrite, ULONG lFileInde, TCHAR *szFileName)
{
    WIN32_FIND_DATA fileInfo;
    HANDLE hFind;
    hFind = FindFirstFile(szFileName, &fileInfo);
    if(INVALID_HANDLE_VALUE != hFind)
        memcpy(ftLastWrite, &fileInfo.ftLastWriteTime, sizeof(FILETIME));
    FindClose(hFind);
    //
    DWORD dwRiveValue = 0x01;
    struct FileEntry tFileEntry;
    if(INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lFileInde)) {
        if(!memcmp(&fileInfo.ftLastWriteTime, &tFileEntry.ftLastWrite, sizeof(FILETIME))) {
            memcpy(szSha1Chks, tFileEntry.szFileChks, SHA1_DIGEST_LEN);
            dwRiveValue = 0x00;
        }
    }
    //
    _LOG_TRACE(_T("valid file sha1:%u"), dwRiveValue);
    return dwRiveValue;
}

ULONG CFilesRiver::FileSha1Update(ULONG lFileInde, unsigned char *szSha1Chks, FILETIME *ftLastWrite, DWORD iListLength)
{
    struct FileEntry tFileEntry;
    //
    if(INVA_INDE_VALU != EntryUtility::ReadNode(m_hFilesRiver, &tFileEntry, lFileInde)) {
        memcpy(tFileEntry.szFileChks, szSha1Chks, SHA1_DIGEST_LEN);
        memcpy(&tFileEntry.ftLastWrite, ftLastWrite, sizeof(FILETIME));
        if(iListLength) tFileEntry.chkslen = iListLength;
        EntryUtility::WriteNode(m_hFilesRiver, &tFileEntry, lFileInde);
    }
    //
    return lFileInde;
}
