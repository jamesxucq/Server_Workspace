#include "StdAfx.h"
#include "CommonUtility.h"

// #include "../../clientcom/utility/ulog.h"
#include "../Logger.h"
#include "ChksUtility.h"
#include "ChksList.h"
#include "FolderUtility.h"
#include "RiverUtility.h"

DWORD EntryUtility::FillIdleEntry(HANDLE hFilesRiver)
{
    struct FileEntry tFileEntry;
    DWORD wlen;
    //
    INIT_FILE_ENTRY(tFileEntry)
    ULONG lIdleOffset = SetFilePointer(hFilesRiver, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!WriteFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &wlen, NULL))
        return ((DWORD)-1);
    //
    return 0x00;
}

ULONG EntryUtility::FindIdleEntry(ULONG *lListHinde, DWORD *iListLength, HANDLE hFilesRiver)
{
    struct FileEntry tFillEntry, tFileEntry;
    ULONG lIdleOffset, lIdleInde = 0;
    DWORD slen, wlen;
    //
    lIdleOffset = SetFilePointer(hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    //
    if(!ReadFile(hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    if(INVA_INDE_VALU != tFillEntry.recycled) {
        lIdleInde = tFillEntry.recycled;
        if(INVA_INDE_VALU == ReadNode(hFilesRiver, &tFileEntry, lIdleInde))
            return INVA_INDE_VALU;
        //
        *lListHinde = tFileEntry.list_hinde;
        *iListLength = tFileEntry.chkslen;
        if(INVA_INDE_VALU != tFileEntry.sibling) {
            tFillEntry.recycled = tFileEntry.sibling;
            ModifyNode(hFilesRiver, tFileEntry.sibling, FILE_INDEX_RECYCLED, tFileEntry.recycled);
        } else tFillEntry.recycled = tFileEntry.recycled;
        //
        OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
        OverLapped.Offset = lIdleOffset;
        if(!WriteFile(hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
            return INVA_INDE_VALU;
    } else {
        if(FillIdleEntry(hFilesRiver)) return INVA_INDE_VALU;
        lIdleInde = lIdleOffset / sizeof(struct FileEntry);
    }
    //
    return lIdleInde;
}

ULONG EntryUtility::AddIdleEntry(HANDLE hFilesRiver, ULONG lFileInde)
{
    struct FileEntry tFillEntry;
    DWORD slen, wlen;
    //
    ULONG lIdleOffset = SetFilePointer(hFilesRiver, -(LONG)sizeof(struct FileEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    //
    if(!ReadFile(hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    ModifyNode(hFilesRiver, lFileInde, FILE_INDEX_RECYCLED, tFillEntry.recycled);
    //
    tFillEntry.recycled = lFileInde;
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lIdleOffset;
    if(!WriteFile(hFilesRiver, &tFillEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;

    // FlushFileBuffers(hFilesRiver);
    return lFileInde;
}

ULONG EntryUtility::ReadNode(HANDLE hFilesRiver, struct FileEntry *pFileEntry, ULONG lFileInde)
{
    DWORD slen;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lFileInde * sizeof(struct FileEntry);
    if(!ReadFile(hFilesRiver, pFileEntry, sizeof(struct FileEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    return lFileInde;
}

ULONG EntryUtility::WriteNode(HANDLE hFilesRiver, struct FileEntry *pFileEntry, ULONG lFileInde)
{
    DWORD wlen;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lFileInde * sizeof(struct FileEntry);
    if(!WriteFile(hFilesRiver, pFileEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}

ULONG EntryUtility::ModifyNode(HANDLE hFilesRiver, ULONG lFileInde, DWORD dwIndeType, ULONG lNextInde)
{
    DWORD slen, wlen;
    struct FileEntry tFileEntry;
    ULONG lExistsInde = INVA_INDE_VALU;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lFileInde * sizeof(struct FileEntry);
    if(!ReadFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    switch(dwIndeType) {
    case FILE_INDEX_ISONYM: // FILE_INDEX_RECYCLED
        lExistsInde = tFileEntry.isonym_nod; // recycled
        tFileEntry.isonym_nod = lNextInde; // recycled
        break;
    case FILE_INDEX_SIBLING:
        lExistsInde = tFileEntry.sibling;
        tFileEntry.sibling = lNextInde;
        break;
    }
    //
    if(!WriteFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lExistsInde;
}

ULONG EntryUtility::VoidNode(HANDLE hFilesRiver, ULONG lFileInde)
{
    DWORD slen, wlen;
    struct FileEntry tFileEntry;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lFileInde * sizeof(struct FileEntry);
    if(!ReadFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
	MKZERO(tFileEntry.szFileName);
    memset(&tFileEntry.szFileChks, '\0', SHA1_DIGEST_LEN);
    if(!WriteFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}

//
ULONG RiverUtility::InitializeEntry(HANDLE hRiverFolder, const TCHAR *szRootPath)
{
    struct FolderEntry tFolderEntry;
    ULONG lFolderInde = ROOT_INDE_VALU;
    //
    INIT_FOLDER_ENTRY(tFolderEntry)
    _tcscpy_s(tFolderEntry.szFolderName, MAX_PATH, szRootPath);
    if(INVA_INDE_VALU == FolderUtility::WriteNode(hRiverFolder, &tFolderEntry, lFolderInde))
        return INVA_INDE_VALU;
    //
    return lFolderInde;
}

DWORD RiverUtility::FillIdleEntry(HANDLE hChksList, HANDLE hFilesRiver, HANDLE hRiverFolder)
{
    DWORD wlen;
    //
    struct ChksEntry tChksEntry;
    INIT_CHKS_ENTRY(tChksEntry)
    ULONG lIdleOffset = SetFilePointer(hChksList, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!WriteFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &wlen, NULL))
        return ((DWORD)-1);
    //
    struct FileEntry tFileEntry;
    INIT_FILE_ENTRY(tFileEntry)
    lIdleOffset = SetFilePointer(hFilesRiver, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!WriteFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &wlen, NULL))
        return ((DWORD)-1);
    //
    struct FolderEntry tFolderEntry;
    INIT_FOLDER_ENTRY(tFolderEntry)
    lIdleOffset = SetFilePointer(hRiverFolder, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!WriteFile(hRiverFolder, &tFolderEntry, sizeof(struct FolderEntry), &wlen, NULL))
        return ((DWORD)-1);
    //
    return 0x00;
}

ULONG RiverUtility::InsFolderLeaf(HANDLE hRiverFolder, ULONG lFolderInde, ULONG lChildInde)
{
    struct FolderEntry tFolderEntry;
    ULONG lFileInde;
    //
    if(INVA_INDE_VALU == FolderUtility::ReadNode(hRiverFolder, &tFolderEntry, lFolderInde))
        return INVA_INDE_VALU;
    //
    lFileInde = tFolderEntry.leaf_inde;
    tFolderEntry.leaf_inde = lChildInde;
    //
    if(INVA_INDE_VALU == FolderUtility::WriteNode(hRiverFolder, &tFolderEntry, lFolderInde))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}

ULONG RiverUtility::InsFileItem(HANDLE hFilesRiver, ULONG lFileInde, ULONG lSibliInde, ULONG lParentInde, ULONG lListInde, TCHAR *szFileName, DWORD chks_tally)
{
    struct FileEntry tFileEntry;
    //
    INIT_FILE_ENTRY(tFileEntry)
    tFileEntry.sibling = lSibliInde;
    tFileEntry.parent = lParentInde;
    _tcscpy_s(tFileEntry.szFileName, MAX_PATH, szFileName);
    tFileEntry.list_hinde = lListInde;
    tFileEntry.chkslen = chks_tally;
    //
    if(INVA_INDE_VALU == EntryUtility::WriteNode(hFilesRiver, &tFileEntry, lFileInde))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}

ULONG RiverUtility::InsFolderItem(HANDLE hRiverFolder, ULONG lFolderInde, ULONG lParentInde, TCHAR *szPathString, LPWIN32_FIND_DATA pFileData)
{
    struct FolderEntry tFolderEntry;
    ULONG lChildInde;
    //
    if(INVA_INDE_VALU == FolderUtility::ReadNode(hRiverFolder, &tFolderEntry, lParentInde))
        return INVA_INDE_VALU;
    //
    lChildInde = tFolderEntry.child;
    tFolderEntry.child = lFolderInde;
    if(INVA_INDE_VALU == FolderUtility::WriteNode(hRiverFolder, &tFolderEntry, lParentInde))
        return INVA_INDE_VALU;
    //
    INIT_FOLDER_ENTRY(tFolderEntry)
    tFolderEntry.ftCreationTime = pFileData->ftCreationTime;
    tFolderEntry.sibling = lChildInde;
    tFolderEntry.parent = lParentInde;
    CommonUtility::full_name(tFolderEntry.szFolderName, szPathString, pFileData->cFileName);
    //
    if(INVA_INDE_VALU == FolderUtility::WriteNode(hRiverFolder, &tFolderEntry, lFolderInde))
        return INVA_INDE_VALU;
    //
    return lFolderInde;
}

ULONG RiverUtility::InsFileIsonym(HANDLE hFilesRiver, ULONG lFileInde, ULONG lIsonymInde)
{
    struct FileEntry tFileEntry;
    DWORD slen, wlen;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lFileInde * sizeof(struct FileEntry);
    //
    if(!ReadFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &slen, &OverLapped)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    tFileEntry.isonym_nod = lIsonymInde;
    if(!WriteFile(hFilesRiver, &tFileEntry, sizeof(struct FileEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lFileInde;
}

ULONG RiverUtility::InsChksListItem(HANDLE hChksList, DWORD chks_tally)
{
    struct ChksEntry tChksEntry;
    //
    if(0x00 == chks_tally) return INVA_INDE_VALU;
    //
    ULONG lListInde = SetFilePointer(hChksList, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lListInde && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    lListInde /= sizeof(struct ChksEntry);
    //
    INIT_CHKS_ENTRY(tChksEntry)
    ULONG lListHinde = lListInde;
    unsigned int ind;
// _LOG_TRACE(_T("lListInde:"));
    for(ind = 1; chks_tally > ind; lListInde++, ind++) {
// _LOG_TRACE(_T("%u "), lListInde);
        tChksEntry.sibling = lListInde + 1;
        if(INVA_INDE_VALU == ChksUtility::WriteNode(hChksList, &tChksEntry, lListInde))
            return INVA_INDE_VALU;
    }
    //
// _LOG_TRACE(_T("%u "), lListInde);
    tChksEntry.sibling = INVA_INDE_VALU;
    if(INVA_INDE_VALU == ChksUtility::WriteNode(hChksList, &tChksEntry, lListInde))
        return INVA_INDE_VALU;
    //
    return lListHinde;
}
