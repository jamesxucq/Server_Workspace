#include "StdAfx.h"

#include "CommonUtility.h"
#include "CreatRiver.h"
#include "ChksUtility.h"
#include "../Logger.h"
#include "../../clientcom/utility/ulog.h"

#include "RiverFS.h"

DWORD RiverFS::Initialize(TCHAR *szLocation, const TCHAR *szDriveRoot)
{
    if(objCreatRiver.BuildRiverEnviro(szLocation, szDriveRoot))
        return ((DWORD)-1);
    if(objChksList.Initialize(szLocation)) return ((DWORD)-1);
    if(objFilesRiver.Initialize(szLocation)) return ((DWORD)-1);
    if(objRiverFolder.Initialize(szLocation)) return ((DWORD)-1);
    return 0x00;
}

DWORD RiverFS::Finalize()
{
    objRiverFolder.Finalize();
    objFilesRiver.Finalize();
    objChksList.Finalize();
    return 0x00;
}

//
DWORD RiverFS::FolderIdenti(TCHAR *szExistsPath, const TCHAR *szFolderPath, FILETIME *ftCreationTime)
{
    if(objRiverFolder.IsDirectory(NO_ROOT(szFolderPath))) // repetition insert
        return RIVER_OPERATE_FOUND;
    //
    DWORD dwIdenValue = RIVER_OPERATE_ADD;
    TCHAR *fileName = _tcsrchr((TCHAR *)szFolderPath, _T('\\'));
    if(fileName) {
        if(objRiverFolder.FindRecycled(NO_ROOT(szExistsPath), ++fileName, ftCreationTime)) {
            dwIdenValue = RIVER_OPERATE_MOVE;
        } else if(objRiverFolder.FindIsonym(NO_ROOT(szExistsPath), fileName, ftCreationTime)) {
            dwIdenValue = RIVER_OPERATE_COPY;
        }
        PATH_ROOT(szExistsPath, szFolderPath)
    }
    //
    return dwIdenValue;
}

DWORD RiverFS::PassFolderValid(const TCHAR *szFolderPath, FILETIME *ftCreationTime)
{
    TCHAR szExistsPath[MAX_PATH];
    DWORD dwPassValid = 0;
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFolderPath, _T('\\'));
    if(fileName) {
        if(objRiverFolder.FindIsonym(NO_ROOT(szExistsPath), ++fileName, ftCreationTime)) {
            if(!_tcscmp(NO_ROOT(szExistsPath), NO_ROOT(szFolderPath))) dwPassValid = 1;
        }
    }
    //
    return dwPassValid;
}

DWORD RiverFS::FolderAppend(const TCHAR *szFolderPath, FILETIME *ftCreationTime)
{
    FolderShadow *pshado;
    DWORD dwRetValue = ((DWORD)-1);
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFolderPath, _T('\\'));
    if(szFolderPath+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        pshado = objRiverFolder.FolderShadowName(NO_ROOT(szFolderPath));
//		if(!pshado) logger(_T("c:\\river.log"), _T("do not find parent:%s\r\n"), szFolderPath);
        fileName[0] = _T('\\');
        dwRetValue = objRiverFolder.InsEntry(NO_ROOT(szFolderPath), ftCreationTime, pshado);
    } else {
        if(pshado = objRiverFolder.FolderShadowPtr(ROOT_INDE_VALU))
            dwRetValue = objRiverFolder.InsEntry(NO_ROOT(szFolderPath), ftCreationTime, pshado);
    }
    //
    return dwRetValue;
}

DWORD RiverFS::FolderAppend(const TCHAR *szFolderPath, const TCHAR *szDriveRoot)
{
    FolderShadow *pshado;
    FILETIME ftCreationTime;
    TCHAR szFolderName[MAX_PATH];
    DWORD dwRetValue = ((DWORD)-1);
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFolderPath, _T('\\'));
    if(szFolderPath != fileName) {
        fileName[0] = _T('\0');
        pshado = objRiverFolder.FolderShadowName(szFolderPath);
        fileName[0] = _T('\\');
        if(pshado) {
            _stprintf_s(szFolderName, MAX_PATH, _T("%s%s"), szDriveRoot, szFolderPath);
            CommonUtility::CreationTime(&ftCreationTime, szFolderName);
            dwRetValue = objRiverFolder.InsEntry(szFolderPath, &ftCreationTime, pshado);
        }
    } else {
        if(pshado = objRiverFolder.FolderShadowPtr(ROOT_INDE_VALU)) {
            _stprintf_s(szFolderName, MAX_PATH, _T("%s%s"), szDriveRoot, szFolderPath);
            CommonUtility::CreationTime(&ftCreationTime, szFolderName);
            dwRetValue = objRiverFolder.InsEntry(szFolderPath, &ftCreationTime, pshado);
        }
    }
    //
    return dwRetValue;
}

DWORD RiverFS::FolderRestore(const TCHAR *szFolderPath, FILETIME *ftCreationTime)
{
    FolderShadow *pshado;
    DWORD dwRetValue = ((DWORD)-1);
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFolderPath, _T('\\'));
    if(szFolderPath+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        pshado = objRiverFolder.FolderShadowName(NO_ROOT(szFolderPath));
        fileName[0] = _T('\\');
        dwRetValue = objRiverFolder.EntryRestore(NO_ROOT(szFolderPath), ftCreationTime, pshado);
    } else dwRetValue = objRiverFolder.EntryRestore(NO_ROOT(szFolderPath), ftCreationTime, objRiverFolder.FolderShadowPtr(ROOT_INDE_VALU));
    //
    return dwRetValue;
}

DWORD RiverFS::FolderMoved(const TCHAR *szExistsPath, const TCHAR *szMovePath)
{
    FolderShadow *pshado;
    DWORD dwRetValue = ((DWORD)-1);
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szMovePath, _T('\\'));
    if(szMovePath+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        pshado = objRiverFolder.FolderShadowName(NO_ROOT(szMovePath));
        fileName[0] = _T('\\');
        dwRetValue = objRiverFolder.MoveEntry(NO_ROOT(szExistsPath), NO_ROOT(szMovePath), pshado);
    } else dwRetValue = objRiverFolder.MoveEntry(NO_ROOT(szExistsPath), NO_ROOT(szMovePath), objRiverFolder.FolderShadowPtr(ROOT_INDE_VALU));
    //
    return dwRetValue;
}

//
BOOL RiverFS::FileExists(const TCHAR *szFileName)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(++fileName, lSibliInde);
    //
    return INVA_INDE_VALU == lFileInde? FALSE: TRUE;
}

DWORD RiverFS::FileIdenti(TCHAR *szExistsFile, struct FileID *pFileID)
{
    // check repetition insert
    if(FileExists(pFileID->szFileName)) return RIVER_OPERATE_FOUND;
    //
    DWORD dwIdenValue = RIVER_OPERATE_ADD;
    TCHAR szParentName[MAX_PATH];
    //
    TCHAR *fileName = _tcsrchr(pFileID->szFileName, _T('\\'));
// logger(_T("c:\\river.log"), _T("\r\nfile name: %s\r\n"), fileName);
    if(fileName) { //
        BOOL bPassValid = FALSE;
        ULONG lParentInde = objFilesRiver.FindRecycled(&bPassValid, ++fileName, pFileID->szFileChks);
// logger(_T("c:\\river.log"), _T("recycled, lParentInde: %u\r\n"), lParentInde);
        if(INVA_INDE_VALU != lParentInde) {
            objRiverFolder.FolderNameIndex(szParentName, lParentInde);
            PATH_ROOT(szExistsFile, pFileID->szFileName)
            _tcscpy_s(NO_ROOT(szExistsFile), MAX_PATH-ROOT_LENGTH, szParentName);
            if(_T('\0') != *(szExistsFile+0x03)) _tcscat_s(szExistsFile, MAX_PATH, _T("\\"));
            _tcscat_s(szExistsFile, MAX_PATH, fileName);
            if(bPassValid) dwIdenValue = RIVER_OPERATE_MOVE;
            else dwIdenValue = OPERATE_MOVE_MODIFY;
        } else { //
            lParentInde = objFilesRiver.FindIsonym(fileName, pFileID);
// logger(_T("c:\\river.log"), _T("isonym, lParentInde: %u\r\n"), lParentInde);
            if(INVA_INDE_VALU != lParentInde) {
                objRiverFolder.FolderNameIndex(szParentName, lParentInde);
                PATH_ROOT(szExistsFile, pFileID->szFileName)
                _tcscpy_s(NO_ROOT(szExistsFile), MAX_PATH-ROOT_LENGTH, szParentName);
                if(_T('\0') != *(szExistsFile+0x03)) _tcscat_s(szExistsFile, MAX_PATH, _T("\\"));
                _tcscat_s(szExistsFile, MAX_PATH, fileName);
                dwIdenValue = RIVER_OPERATE_COPY;
            }
        } //
    }
    //
    return dwIdenValue;
}

DWORD RiverFS::PassFileValid(const TCHAR *szExistsFile, struct FileID *pFileID)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szExistsFile, _T('\\'));
    if(szExistsFile+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szExistsFile));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(++fileName, lSibliInde, pFileID->szFileChks);
    //
    return (INVA_INDE_VALU == lFileInde) ? 0: 1;
}

ULONG RiverFS::FileAppend(struct FileID *pFileID)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr(pFileID->szFileName, _T('\\'));
    if(pFileID->szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(pFileID->szFileName));
        fileName[0] = _T('\\');
        lFileInde = objFilesRiver.InsEntry(++fileName, pFileID, lParentInde, lSibliInde);
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        lFileInde = objFilesRiver.InsEntry(++fileName, pFileID, ROOT_INDE_VALU, lSibliInde);
        objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lFileInde);
    }
    //
    return lFileInde;
}

ULONG RiverFS::DeleteFile(const TCHAR *szFileName)
{
    ULONG lNextInde, lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
        lFileInde = objFilesRiver.DelFileEntry(&lNextInde, ++fileName, lSibliInde);
        if(lSibliInde == lFileInde)
            objRiverFolder.SetChildIndex(lParentInde, lNextInde);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        lFileInde = objFilesRiver.DelFileEntry(&lNextInde, ++fileName, lSibliInde);
        if(lSibliInde == lFileInde)
            objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lNextInde);
    }
    //
    return lFileInde;
}

ULONG RiverFS::FileRestore(const TCHAR *szFileName)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr((TCHAR *)szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
        lFileInde = objFilesRiver.EntryRestore(++fileName, lParentInde, lSibliInde, szFileName);
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        lFileInde = objFilesRiver.EntryRestore(++fileName, ROOT_INDE_VALU, lSibliInde, szFileName);
        objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lFileInde);
    }
    //
    return lFileInde;
}

ULONG RiverFS::FileRestore(struct FileID *pFileID)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *fileName = _tcsrchr(pFileID->szFileName, _T('\\'));
    if(pFileID->szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(pFileID->szFileName));
        fileName[0] = _T('\\');
        lFileInde = objFilesRiver.EntryRestore(++fileName, lParentInde, lSibliInde, pFileID);
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        lFileInde = objFilesRiver.EntryRestore(++fileName, ROOT_INDE_VALU, lSibliInde, pFileID);
        objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lFileInde);
    }
    //
    return lFileInde;
}

ULONG RiverFS::FileMoved(const TCHAR *szExistsFile, const TCHAR *szMoveFile)
{
    ULONG lNextInde, lSibliInde, lParentInde, lFileInde;
    //
    TCHAR *eFileName = _tcsrchr((TCHAR *)szExistsFile, _T('\\'));
    if(szExistsFile+ROOT_LENGTH != eFileName) {
        eFileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szExistsFile));
        eFileName[0] = _T('\\');
        lFileInde = objFilesRiver.ExistsEntry(&lNextInde, ++eFileName, lSibliInde);
        if(lSibliInde == lFileInde)
            objRiverFolder.SetChildIndex(lParentInde, lNextInde);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        lFileInde = objFilesRiver.ExistsEntry(&lNextInde, ++eFileName, lSibliInde);
        if(lSibliInde == lFileInde)
            objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lNextInde);
        lParentInde = ROOT_INDE_VALU;
    }
    // �ݴ� INVA_INDE_VALU == lFileInde
    if(INVA_INDE_VALU == lFileInde) { // do not find file entry, insert new entry.
        lFileInde = objFilesRiver.InsEntry(NULL, 0, eFileName, lParentInde, lSibliInde);
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
		_LOG_WARN(_T("fault tolerance. fileName:%s"), eFileName);
    }
    //
    TCHAR *nFileName = _tcsrchr((TCHAR *)szMoveFile, _T('\\'));
    if(szMoveFile+ROOT_LENGTH != nFileName) {
        nFileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szMoveFile));
        nFileName[0] = _T('\\');
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
        lFileInde = objFilesRiver.MoveEntry(lFileInde, lParentInde, lSibliInde, eFileName, ++nFileName);
    } else {
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
        objRiverFolder.SetChildIndex(ROOT_INDE_VALU, lFileInde);
        lFileInde = objFilesRiver.MoveEntry(lFileInde, ROOT_INDE_VALU, lSibliInde, eFileName, ++nFileName);
    }
    //
    return lFileInde;
}

//
VOID RiverFS::VoidRecycled()
{
	_LOG_TRACE(_T("river void recycled"));
    objRiverFolder.VoidRecycled();
    objFilesRiver.VoidRecycled();
}

//
DWORD RiverFS::InitFileID(struct FileID *pFileID, const TCHAR *szFileName, BOOL bFileExists) // maybe file not exists
{
	_tcscpy_s(pFileID->szFileName, MAX_PATH, szFileName);
	if(bFileExists) {
		pFileID->hRiveChks = ChksUtility::ChksFileHandle();
		if(INVALID_HANDLE_VALUE == pFileID->hRiveChks) return 0x01;
		ChksUtility::CreatChksFile(pFileID->hRiveChks, szFileName);
		ChksUtility::FileSha1Chks(pFileID->szFileChks, pFileID->hRiveChks);
		//
		CommonUtility::FileSizeTimeExt(&pFileID->qwFileSize, &pFileID->ftLastWrite, szFileName);
	}
	return 0x00;
}

DWORD RiverFS::ChunkWriteUpdate(const TCHAR *szFileName, DWORD iListPosit, FILETIME *ftLastWrite) // no root
{
    TCHAR szFilePath[MAX_PATH];
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
// _LOG_TRACE(_T("chunk write update, file:%s posit:%d last_write:%llu"), szFileName, iListPosit, *ftLastWrite);
    _tcscpy_s(szFilePath, MAX_PATH, szFileName);
    TCHAR *fileName = _tcsrchr(szFilePath, _T('\\'));
    if(szFilePath != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, szFilePath);
        fileName[0] = _T('\\');
    } else {
        lParentInde = ROOT_INDE_VALU;
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    }
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
    //
    if(INVA_INDE_VALU == lFileInde) return 0x01; // do not find file entry, insert new entry
    if(objChksList.ChunkLastWrite(lListInde, &iListLength, iListPosit, ftLastWrite))
        objFilesRiver.FileChklenUpdate(lFileInde, iListLength);
    //
    return 0x00;
}

BOOL RiverFS::FolderMaker(const TCHAR *szFolderPath, const TCHAR *szDriveRoot)
{
    TCHAR szParent[MAX_PATH];
    //
    if(objRiverFolder.IsDirectory(szFolderPath) || !FolderAppend(szFolderPath, szDriveRoot))
        return TRUE;
    CommonUtility::GetFileFolderPath(szParent, szFolderPath);
    if (!FolderMaker(szParent, szDriveRoot) || FolderAppend(szFolderPath, szDriveRoot))
        return FALSE;
    //
    return TRUE;
}

DWORD RiverFS::ChunkUpdate(const TCHAR *szFileName, DWORD iListPosit, unsigned char *md5_chks, FILETIME *ftLastWrite, const TCHAR *szDriveRoot)
{
    TCHAR szFilePath[MAX_PATH];
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
    _LOG_TRACE(_T("chunk update, file:%s posit:%d last_write:%llu"), szFileName, iListPosit, *ftLastWrite);
    _tcscpy_s(szFilePath, MAX_PATH, szFileName);
    lParentInde = INVA_INDE_VALU;
    TCHAR *fileName = _tcsrchr(szFilePath, _T('\\'));
    if(szFilePath != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, szFilePath);
        if(INVA_INDE_VALU == lParentInde) { // do not find dir, recursive create
            FolderMaker(szFilePath, szDriveRoot);
            lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, szFilePath);
        }
        fileName[0] = _T('\\');
    } else {
        lParentInde = ROOT_INDE_VALU;
        lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    }
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
    //
    if(INVA_INDE_VALU == lFileInde) { // do not find file entry, insert new entry.
        iListLength = 1 + iListPosit;
        lFileInde = objFilesRiver.InsEntry(&lListInde, iListLength, fileName, lParentInde, lSibliInde);
        objRiverFolder.SetChildIndex(lParentInde, lFileInde);
    }
    if(objChksList.ChunkUpdate(lListInde, &iListLength, iListPosit, md5_chks, ftLastWrite))
        objFilesRiver.FileChklenUpdate(lFileInde, iListLength);
    //
    return 0x00;
}

/*
DWORD RiverFS::ValidFileChks(TCHAR *szFileName, DWORD iListPosit)   // 0:okay 1:valid error
{
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
    TCHAR *fileName = _tcsrchr(szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
// _LOG_TRACE(_T("lFileInde:%X file:%s"), lFileInde, szFileName);
    if(INVA_INDE_VALU == lFileInde) return 0x00;
    //
    return objChksList.ValidFileChks(szFileName, lListInde, iListLength, iListPosit);
}
*/

//
DWORD RiverFS::FileSha1(unsigned char *szSha1Chks, TCHAR *szFileName)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
    TCHAR *fileName = _tcsrchr(szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
    //
    if(INVA_INDE_VALU == lFileInde) return 0x01;
    FILETIME ftLastWrite;
    if(objFilesRiver.ValidFileSha1(szSha1Chks, &ftLastWrite, lFileInde, szFileName)) {
        DWORD dwRiveValue = objChksList.FileSha1(szSha1Chks, szFileName, lListInde, &iListLength);
        if(!dwRiveValue || 0x01&dwRiveValue)
            objFilesRiver.FileSha1Update(lFileInde, szSha1Chks, &ftLastWrite, iListLength);
        if(0x02 & dwRiveValue) return 0x02;
    }
    //
    return 0x00;
}

DWORD RiverFS::FileChks(HANDLE hRiveChks, TCHAR *szFileName, DWORD iListPosit)   // 0:okay 1:chkslen
{
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
    TCHAR *fileName = _tcsrchr(szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
    //
    if(INVA_INDE_VALU == lFileInde) return 0x01;
    DWORD dwRiveValue = objChksList.FileChks(hRiveChks, szFileName, lListInde, &iListLength, iListPosit);
    if(dwRiveValue) {
        if(0x01 & dwRiveValue)
            objFilesRiver.FileChklenUpdate(lFileInde, iListLength);
        if(0x02 & dwRiveValue) return 0x02;
    }
    //
    return 0x00;
}

DWORD RiverFS::ChunkChks(struct riv_chks *pRiveChks, TCHAR *szFileName, DWORD iListPosit)
{
    ULONG lSibliInde, lParentInde, lFileInde;
    ULONG lListInde = INVA_INDE_VALU;
    DWORD iListLength;
    //
    TCHAR *fileName = _tcsrchr(szFileName, _T('\\'));
    if(szFileName+ROOT_LENGTH != fileName) {
        fileName[0] = _T('\0');
        lSibliInde = objRiverFolder.FileSiblingIndex(&lParentInde, NO_ROOT(szFileName));
        fileName[0] = _T('\\');
    } else lSibliInde = objRiverFolder.FileSiblingIndex(ROOT_INDE_VALU);
    lFileInde = objFilesRiver.FindFileEntry(&lListInde, &iListLength, ++fileName, lSibliInde);
    //
    if(INVA_INDE_VALU == lFileInde) return 0x01;
    if(objChksList.ChunkChks(pRiveChks, szFileName, lListInde, &iListLength, iListPosit))
        objFilesRiver.FileChklenUpdate(lFileInde, iListLength);
    //
    return 0x00;
}