#pragma once
//

struct FileEntry {
	ULONG sibling, parent;
	union {
		ULONG isonym_nod;
		ULONG recycled;
	};
	//
	TCHAR szFileName[MAX_PATH];
	unsigned char szFileChks[SHA1_DIGEST_LEN];
	FILETIME ftLastWrite;
	ULONG list_hinde;
	DWORD chkslen; /* chunk length */
};

#define INIT_FILE_ENTRY(entry) \
	memset(&entry, '\0', sizeof(struct FileEntry)); \
	entry.sibling = INVA_INDE_VALU; \
	entry.parent = INVA_INDE_VALU;\
	entry.isonym_nod = INVA_INDE_VALU;\
	entry.list_hinde = INVA_INDE_VALU;

namespace EntryUtility
{
	DWORD FillIdleEntry(HANDLE hFilesRiver);
	ULONG FindIdleEntry(ULONG *lListHinde, DWORD *iListLength, HANDLE hFilesRiver);
	ULONG AddIdleEntry(HANDLE hFilesRiver, ULONG lIdleInde);
	ULONG ReadNode(HANDLE hFilesRiver, struct FileEntry *pFileEntry, ULONG lFileInde);
	ULONG WriteNode(HANDLE hFilesRiver, struct FileEntry *pFileEntry, ULONG lFileInde);
	ULONG ModifyNode(HANDLE hFilesRiver, ULONG lFileInde, DWORD dwIndeType, ULONG lNextInde);
	ULONG VoidNode(HANDLE hFilesRiver, ULONG lFileInde);
}

//
namespace RiverUtility
{
	DWORD FillIdleEntry(HANDLE hChksList, HANDLE hFilesRiver, HANDLE hRiverFolder);
	ULONG InitializeEntry(HANDLE hRiverFolder, const TCHAR *szRootPath);
	ULONG InsFolderLeaf(HANDLE hRiverFolder, ULONG lFolderInde, ULONG lChildInde);
	ULONG InsFileItem(HANDLE hFilesRiver, ULONG lFileInde, ULONG lSibliInde, ULONG lParentInde, ULONG lListInde, TCHAR *szFileName, DWORD chks_tally);
	ULONG InsFolderItem(HANDLE hRiverFolder, ULONG lFolderInde, ULONG lParentInde, TCHAR *szPathString, LPWIN32_FIND_DATA pFileData);
	ULONG InsFileIsonym(HANDLE hFilesRiver, ULONG lFileInde, ULONG lIsonymInde);
	//
	ULONG InsChksListItem(HANDLE hChksList, DWORD chks_tally);
};
//