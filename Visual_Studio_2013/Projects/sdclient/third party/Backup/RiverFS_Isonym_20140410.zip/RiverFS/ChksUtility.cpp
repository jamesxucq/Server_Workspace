#include "StdAfx.h"

#include "CommonUtility.h"
#include "Sha1.h"
// #include "../../clientcom/utility/ulog.h"
#include "../Logger.h"
#include "ChksList.h"
#include "ChksUtility.h"

//

#define MAX_UPDATE_NUM	256

//

HANDLE ChksUtility::ChksFileHandle()
{
    TCHAR szDirectory[MAX_PATH];
    TCHAR szFileName[MAX_PATH];
    //
    GetTempPath(MAX_PATH, szDirectory);
    GetTempFileName(szDirectory, _T("sdclient"), 0, szFileName);
    //
    HANDLE hFileChks = CreateFile( szFileName,
                                   GENERIC_WRITE | GENERIC_READ,
                                   NULL, /* FILE_SHARE_READ */
                                   NULL,
                                   CREATE_ALWAYS,
                                   FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE,
                                   NULL);
    if( INVALID_HANDLE_VALUE == hFileChks ) {
        _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
        _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
        return INVALID_HANDLE_VALUE;
    }
    //
    return hFileChks;
}

VOID ChksMD5(TCHAR *label, unsigned char *md5sum)
{
    TCHAR chksum_str[64];
    for (int i=0; i<16; i++)
        _stprintf_s (chksum_str+i*2, 33, _T("%02x"), md5sum[i]);
    chksum_str[32] = _T('\0');
    _LOG_DEBUG(_T("%s:%s"), label, chksum_str);
}

HANDLE ChksUtility::CreatChksFile(HANDLE hFileRiver, const TCHAR *szFileName)
{
    HANDLE hFileChks = CreateFile( szFileName,
                                   GENERIC_READ,
                                   FILE_SHARE_READ,
                                   NULL,
                                   OPEN_EXISTING,
                                   FILE_ATTRIBUTE_NORMAL,
                                   NULL);
    if( INVALID_HANDLE_VALUE == hFileChks ) {
        _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
        _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
        return INVALID_HANDLE_VALUE;
    }
    DWORD dwFileSizeHigh;
    unsigned __int64 qwFileSize = GetFileSize(hFileChks, &dwFileSizeHigh);
    qwFileSize += (((unsigned __int64)dwFileSizeHigh) << 32);
    unsigned int chks_tally = (unsigned int)(qwFileSize >> 22); // (vlength / CHUNK_SIZE);
    if (POW2N_MOD(qwFileSize, CHUNK_SIZE)) chks_tally++;
    //
    struct riv_chks rchks;
    DWORD wlen;
    for (unsigned int inde = 0; inde < chks_tally; inde++) {
        rchks.offset = ((unsigned __int64)inde) * CHUNK_SIZE;
        CommonUtility::chunk_chks(rchks.md5_chks, hFileChks, qwFileSize, rchks.offset);
// _LOG_TRACE(_T("rchks.offset: %llu chunk:%d"), rchks.offset, rchks.offset>>22);
// ChksMD5(_T("rchks.md5_chks"), rchks.md5_chks);
        if(!WriteFile(hFileRiver, &rchks, sizeof(struct riv_chks), &wlen, NULL))
            break;
    }
    //
    if(INVALID_HANDLE_VALUE != hFileChks) {
        CloseHandle( hFileChks );
        hFileChks = INVALID_HANDLE_VALUE;
    }
    //
    return hFileRiver;
}

VOID ChksUtility::FileSha1Chks(unsigned char *sha1_chks, HANDLE hRiveChks)
{
    DWORD dwResult = SetFilePointer(hRiveChks, 0, NULL, FILE_BEGIN);
    if(INVALID_SET_FILE_POINTER==dwResult && NO_ERROR!=GetLastError())
        return;
    //
    struct riv_chks rchks;
    sha1_ctx cx[1];
    DWORD dwReadSize;
    //
    sha1_begin(cx);
    while(ReadFile(hRiveChks, &rchks, sizeof(struct riv_chks), &dwReadSize, NULL) && 0 < dwReadSize) {
        sha1_hash(rchks.md5_chks, MD5_DIGEST_LEN, cx);
    }
// ChksMD5(_T("1 sha1_chks"), sha1_chks);
    sha1_end(sha1_chks, cx);
// ChksMD5(_T("2 sha1_chks"), sha1_chks);
}

VOID ChksUtility::FileSha1Chks(unsigned char *sha1_chks, HANDLE hChksList, ULONG lListInde)
{
    struct ChksEntry tChksEntry;
    sha1_ctx cx[1];
    //
    tChksEntry.sibling = lListInde;
    sha1_begin(cx);
    while (INVA_INDE_VALU != tChksEntry.sibling) {
_LOG_TRACE(_T("read chks lListPosit:%u"), tChksEntry.sibling); // disable by james 20140115
        ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        sha1_hash(tChksEntry.szFileChks, MD5_DIGEST_LEN, cx);
    }
// ChksMD5(_T("1 sha1_chks"), sha1_chks);
    sha1_end(sha1_chks, cx);
// ChksMD5(_T("2 sha1_chks"), sha1_chks);
}

//
DWORD ChksUtility::FillIdleEntry(HANDLE hChksList)
{
    struct ChksEntry tChksEntry;
    DWORD wlen;
    //
    INIT_CHKS_ENTRY(tChksEntry)
    ULONG lIdleOffset = SetFilePointer(hChksList, 0, NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ((DWORD)-1);
    if(!WriteFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &wlen, NULL))
        return ((DWORD)-1);
    //
    return 0x00;
}

ULONG ChksUtility::FindIdleEntry(HANDLE hChksList)
{
    struct ChksEntry tFillEntry, tChksEntry;
    ULONG lIdleOffset, lIdleInde = 0;
    DWORD slen, wlen;
    //
    lIdleOffset = SetFilePointer(hChksList, -(LONG)sizeof(struct ChksEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    //
    if(!ReadFile(hChksList, &tFillEntry, sizeof(struct ChksEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    if(INVA_INDE_VALU != tFillEntry.recycled) {
        lIdleInde = tFillEntry.recycled;
        if(INVA_INDE_VALU == ReadNode(hChksList, &tChksEntry, lIdleInde))
            return INVA_INDE_VALU;
        // _LOG_TRACE(_T("idle entry:%u sibling:%u recycled:%u"), lIdleInde, tChksEntry.sibling, tChksEntry.recycled);
        memset(&tChksEntry.ftLastWrite, 0, sizeof(FILETIME));
        if(INVA_INDE_VALU == WriteNode(hChksList, &tChksEntry, lIdleInde))
            return INVA_INDE_VALU;
        //
        if(INVA_INDE_VALU != tChksEntry.sibling) {
            tFillEntry.recycled = tChksEntry.sibling;
            ModifyNode(hChksList, tChksEntry.sibling, LIST_INDEX_RECYCLED, tChksEntry.recycled);
        } else tFillEntry.recycled = tChksEntry.recycled;
        //
        OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
        OverLapped.Offset = lIdleOffset;
        if(!WriteFile(hChksList, &tFillEntry, sizeof(struct ChksEntry), &wlen, &OverLapped))
            return INVA_INDE_VALU;
    } else {
        if(FillIdleEntry(hChksList)) return INVA_INDE_VALU;
        lIdleInde = lIdleOffset / sizeof(struct ChksEntry);
    }
    //
    return lIdleInde;
}

ULONG ChksUtility::AddIdleEntry(HANDLE hChksList, ULONG lListInde)
{
    struct ChksEntry tFillEntry;
    DWORD slen, wlen;
    //
    ULONG lIdleOffset = SetFilePointer(hChksList, -(LONG)sizeof(struct ChksEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return INVA_INDE_VALU;
    //
    if(!ReadFile(hChksList, &tFillEntry, sizeof(struct ChksEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return INVA_INDE_VALU;
    }
    //
    ModifyNode(hChksList, lListInde, LIST_INDEX_RECYCLED, tFillEntry.recycled);
    //
    tFillEntry.recycled = lListInde;
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lIdleOffset;
    if(!WriteFile(hChksList, &tFillEntry, sizeof(struct ChksEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    // FlushFileBuffers(hChksList);
    return lListInde;
}

ULONG ChksUtility::ReadNode(HANDLE hChksList, struct ChksEntry *pChksEntry, ULONG lListInde)
{
    DWORD slen;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lListInde * sizeof(struct ChksEntry);
    if(!ReadFile(hChksList, pChksEntry, sizeof(struct ChksEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    return lListInde;
}

ULONG ChksUtility::WriteNode(HANDLE hChksList, struct ChksEntry *pChksEntry, ULONG lListInde)
{
    DWORD wlen;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lListInde * sizeof(struct ChksEntry);
    if(!WriteFile(hChksList, pChksEntry, sizeof(struct ChksEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lListInde;
}

ULONG ChksUtility::ModifyNode(HANDLE hChksList, ULONG lListInde, DWORD dwIndeType, ULONG lNextInde)
{
    DWORD slen, wlen;
    struct ChksEntry tChksEntry;
    ULONG lExistsInde = INVA_INDE_VALU;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lListInde * sizeof(struct ChksEntry);
    if(!ReadFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    switch(dwIndeType) {
    case LIST_INDEX_SIBLING:
        lExistsInde = tChksEntry.sibling;
        tChksEntry.sibling = lNextInde;
        break;
    case LIST_INDEX_RECYCLED:
        lExistsInde = tChksEntry.recycled;
        tChksEntry.recycled = lNextInde;
        break;
    }
    //
    if(!WriteFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lExistsInde;
}

DWORD ChksUtility::ListLength(HANDLE hChksList, ULONG lListHinde) // for test
{
    struct ChksEntry tChksEntry;
    unsigned int ind;
    //
// _LOG_TRACE(_T("list length alloc block:"));
    tChksEntry.sibling = lListHinde;
    for(ind = 0; INVA_INDE_VALU != tChksEntry.sibling; ind++) {
// _LOG_TRACE(_T(" %u"), tChksEntry.sibling);
        ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
    }
    //
    return ind;
}

DWORD ChksUtility::ListEntry(HANDLE hChksList, ULONG lListHinde) // for test
{
    struct ChksEntry tChksEntry;
    unsigned int ind;
    //
// _LOG_TRACE(_T("block info:"));
    tChksEntry.sibling = lListHinde;
    for(ind = 0; INVA_INDE_VALU != tChksEntry.sibling; ind++) {
// _LOG_TRACE(_T(" inde:%u"), tChksEntry.sibling);
        ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
// _LOG_TRACE(_T(" last_write:%lld"), tChksEntry.ftLastWrite);
    }
    //
    return ind;
}

VOID ChksUtility::ChksIdleEntry(HANDLE hChksList)  // for test
{
    struct ChksEntry tFillEntry, tChksEntry;
    ULONG lIdleOffset, lIdleInde = 0;
    DWORD slen;
    //
    lIdleOffset = SetFilePointer(hChksList, -(LONG)sizeof(struct ChksEntry), NULL, FILE_END);
    if(INVALID_SET_FILE_POINTER==lIdleOffset && NO_ERROR!=GetLastError())
        return ;
    //
    if(!ReadFile(hChksList, &tFillEntry, sizeof(struct ChksEntry), &slen, NULL)) {
        if(ERROR_HANDLE_EOF != GetLastError()) return ;
    }
    //
// _LOG_TRACE(_T("idle list alloc block:"));
    ULONG lRecyclInde;
    for(lRecyclInde = tFillEntry.recycled; INVA_INDE_VALU != ReadNode(hChksList, &tChksEntry, lRecyclInde); ) {
// _LOG_TRACE(_T(" r:%u s:%u"), lRecyclInde, tChksEntry.sibling);
        lRecyclInde = tChksEntry.recycled;
        for(; INVA_INDE_VALU != ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);) {
            if(INVA_INDE_VALU != tChksEntry.sibling) {
// _LOG_TRACE(_T(" s:%u"), tChksEntry.sibling);
            }
        }
    }
}

ULONG FindSibliEntry(HANDLE hChksList, ULONG lListInde)
{
    DWORD slen;
    struct ChksEntry tChksEntry;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lListInde * sizeof(struct ChksEntry);
    if(!ReadFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    return tChksEntry.sibling;
}

ULONG ChksUtility::ResetListLength(HANDLE hChksList, ULONG lListHinde, DWORD iOldLength, DWORD iNewLength)
{
    int diff_clen = iNewLength - iOldLength;
    int ind;
    ULONG eind, nind, sibli;
    //
    if(0 < diff_clen) { // make long then old
        for (nind = lListHinde; INVA_INDE_VALU != (sibli = FindSibliEntry(hChksList, nind)); nind = sibli);
        //
        eind = FindIdleEntry(hChksList);
        if (INVA_INDE_VALU == nind) lListHinde = eind;
        ModifyNode(hChksList, nind, LIST_INDEX_SIBLING, eind);
        nind = eind;
        //
        for (ind = 0x01; diff_clen > ind; ind++) {
            eind = FindIdleEntry(hChksList);
            // printf("nind:%llu eind:%llu\n", nind, eind);
            ModifyNode(hChksList, nind, LIST_INDEX_SIBLING, eind);
            nind = eind;
        }
    } else if(0 > diff_clen) { // make short
        nind = INVA_INDE_VALU;
        for (sibli = lListHinde, ind = 0x00; (int)iNewLength > ind; ind++) {
            nind = sibli;
            sibli = FindSibliEntry(hChksList, sibli);
        }
        AddIdleEntry(hChksList, sibli);
        if(INVA_INDE_VALU == nind) lListHinde = INVA_INDE_VALU;
        else ModifyNode(hChksList, nind, LIST_INDEX_SIBLING, INVA_INDE_VALU);
    }
    //
    return lListHinde;
}

ULONG ChksUtility::ModifyNode(HANDLE hChksList, ULONG lListInde, unsigned char *md5_chks, FILETIME *ftLastWrite)
{
    DWORD slen, wlen;
    struct ChksEntry tChksEntry;
    ULONG lNextInde = INVA_INDE_VALU;
    //
    OVERLAPPED OverLapped = {0, 0, 0, 0, NULL}; // used for file unlocks.
    OverLapped.Offset = lListInde * sizeof(struct ChksEntry);
    if(!ReadFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &slen, &OverLapped)) {
        // if(ERROR_HANDLE_EOF != GetLastError())
        return INVA_INDE_VALU;
    }
    //
    lNextInde = tChksEntry.sibling;
    memcpy(&tChksEntry.ftLastWrite, ftLastWrite, sizeof(FILETIME));
    memcpy(tChksEntry.szFileChks, md5_chks, MD5_DIGEST_LEN);
    //
    if(!WriteFile(hChksList, &tChksEntry, sizeof(struct ChksEntry), &wlen, &OverLapped))
        return INVA_INDE_VALU;
    //
    return lNextInde;
}

//
/*
DWORD ChksUtility::ValidChunkUpdate(HANDLE hChksList, ULONG lListHinde, DWORD iListPosit, FILETIME *ftLastWrite)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind;
    //
    if (INVA_INDE_VALU == lListHinde) return 0x00;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; iListPosit > ind; ind++) {
// _LOG_TRACE(_T("--- tChksEntry.sibling:%u"), tChksEntry.sibling); // disable by james 20140115
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (INVA_INDE_VALU == lListInde) return 0x00;
    }
    //
    DWORD dwValidTally = 0x00;
    while(INVA_INDE_VALU != tChksEntry.sibling) {
// _LOG_TRACE(_T("+++ tChksEntry.sibling:%u"), tChksEntry.sibling); // disable by james 20140115
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (memcmp(&tChksEntry.ftLastWrite, ftLastWrite, sizeof(FILETIME))) {
            ++dwValidTally;
        }
// _LOG_TRACE(_T("dwValidTally:%u"), dwValidTally); // disable by james 20140115
    }
    //
    return dwValidTally;
}
*/

DWORD ChksUtility::FileChksUpdate(HANDLE hChksList, const TCHAR *szFilePath, ULONG lListHinde, WIN32_FIND_DATA *fileInfo)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind, update_tally = 0x01;
    //
    // if (INVA_INDE_VALU == lListHinde) return 0x01;
    HANDLE hChunk = CreateFile( szFilePath,
                                /* GENERIC_WRITE | */ GENERIC_READ,
                                NULL, /* FILE_SHARE_READ */
                                NULL,
                                OPEN_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
    if( INVALID_HANDLE_VALUE == hChunk ) {
        _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
        _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
        return 0x01;
    }
    //
    unsigned __int64 qwFileSize = fileInfo->nFileSizeLow;
    qwFileSize += ((unsigned __int64)fileInfo->nFileSizeHigh) << 32;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; INVA_INDE_VALU != tChksEntry.sibling; ind++) {
        if(MAX_UPDATE_NUM < update_tally) {
            if(INVALID_HANDLE_VALUE != hChunk) {
                CloseHandle( hChunk );
                hChunk = INVALID_HANDLE_VALUE;
            }
            return 0x02;
        }
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (memcmp(&tChksEntry.ftLastWrite, &fileInfo->ftLastWriteTime, sizeof(FILETIME))) {
            update_tally++;
_LOG_TRACE(_T("1 update chunk chks. lListInde:%u"), lListInde);
            CommonUtility::chunk_chks(tChksEntry.szFileChks, hChunk, qwFileSize, ((unsigned __int64)ind) << 22);
            tChksEntry.ftLastWrite = fileInfo->ftLastWriteTime;
            WriteNode(hChksList, &tChksEntry, lListInde);
            // printf("update chks, lListInde:%llu tChksEntry.time_stamp:%ld\n", lListInde, tChksEntry.time_stamp);
        }
    }
    //
    if(INVALID_HANDLE_VALUE != hChunk) {
        CloseHandle( hChunk );
        hChunk = INVALID_HANDLE_VALUE;
    }
    return 0x00;
}

DWORD ChksUtility::FileChunkUpdate(HANDLE hChksList, ULONG *lIndePosit, const TCHAR *szFilePath, ULONG lListHinde, DWORD iListPosit, WIN32_FIND_DATA *fileInfo)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind, update_tally = 0x01;
    //
    if (INVA_INDE_VALU == lListHinde) return 0x01;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; iListPosit > ind; ind++) {
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (INVA_INDE_VALU == lListInde) return 0x01;
    }
    //
    HANDLE hChunk = CreateFile( szFilePath,
                                /* GENERIC_WRITE | */ GENERIC_READ,
                                NULL, /* FILE_SHARE_READ */
                                NULL,
                                OPEN_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
    if( INVALID_HANDLE_VALUE == hChunk ) {
        _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
        _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
        return 0x01;
    }
    //
    unsigned __int64 qwFileSize = fileInfo->nFileSizeLow;
    qwFileSize += ((unsigned __int64)fileInfo->nFileSizeHigh) << 32;
    if(lIndePosit) *lIndePosit = tChksEntry.sibling;
    for (; INVA_INDE_VALU != tChksEntry.sibling; ind++) {
        if(MAX_UPDATE_NUM < update_tally) {
            if(INVALID_HANDLE_VALUE != hChunk) {
                CloseHandle( hChunk );
                hChunk = INVALID_HANDLE_VALUE;
            }
            return 0x02;
        }
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (memcmp(&tChksEntry.ftLastWrite, &fileInfo->ftLastWriteTime, sizeof(FILETIME))) {
            update_tally++;
// _LOG_TRACE(_T("2 update chunk chks. lListInde:%u"), lListInde);
            CommonUtility::chunk_chks(tChksEntry.szFileChks, hChunk, qwFileSize, ((unsigned __int64)ind) << 22);
            tChksEntry.ftLastWrite = fileInfo->ftLastWriteTime;
            WriteNode(hChksList, &tChksEntry, lListInde);
            // printf("update chks, lListInde:%llu tChksEntry.time_stamp:%ld\n", lListInde, tChksEntry.time_stamp);
        }
    }
    //
    if(INVALID_HANDLE_VALUE != hChunk) {
        CloseHandle( hChunk );
        hChunk = INVALID_HANDLE_VALUE;
    }
    return 0x00;
}

DWORD ChksUtility::FileRiveChks(HANDLE hRiveChks, HANDLE hChksList, ULONG lListPosit)
{
    struct ChksEntry tChksEntry;
    struct riv_chks rchks;
    DWORD wlen, ind;
    //
    tChksEntry.sibling = lListPosit;
    for (ind = 0; INVA_INDE_VALU != tChksEntry.sibling; ind++) {
        // _LOG_TRACE(_T("read chks lListPosit:%u"), tChksEntry.sibling);
        if (INVA_INDE_VALU == ReadNode(hChksList, &tChksEntry, tChksEntry.sibling))
            return 0x01;
        memcpy(rchks.md5_chks, tChksEntry.szFileChks, MD5_DIGEST_LEN);
        rchks.offset = ((unsigned __int64)ind) << 22;
        // memcpy(&pRiveChks[ind], &rchks, sizeof(struct riv_chks));
        if(!WriteFile(hRiveChks, &rchks, sizeof(struct riv_chks), &wlen, NULL))
            return 0x01;
    }
    return 0x00;
}

ULONG ChksUtility::ChunkChksUpdate(HANDLE hChksList, const TCHAR *szFilePath, ULONG lListHinde, DWORD iListPosit, WIN32_FIND_DATA *fileInfo)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind;
    //
    if (INVA_INDE_VALU == lListHinde) return INVA_INDE_VALU;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; iListPosit >= ind; ind++) {
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (INVA_INDE_VALU == lListInde) return INVA_INDE_VALU;
    }
    //
    if (memcmp(&tChksEntry.ftLastWrite, &fileInfo->ftLastWriteTime, sizeof(FILETIME))) {
        // _LOG_TRACE(_T("update chunk chks. iListPosit:%u"), iListPosit);
        HANDLE hChunk = CreateFile( szFilePath,
                                    /* GENERIC_WRITE | */ GENERIC_READ,
                                    NULL, /* FILE_SHARE_READ */
                                    NULL,
                                    OPEN_ALWAYS,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL);
        if( INVALID_HANDLE_VALUE == hChunk ) {
            _LOG_TRACE( _T("create file failed: %d"), GetLastError() );
            _LOG_TRACE(_T(" File: %s Line: %d"), _T(__FILE__), __LINE__);
            return INVA_INDE_VALU;
        }
        //
        unsigned __int64 qwFileSize = fileInfo->nFileSizeLow;
        qwFileSize += ((unsigned __int64)fileInfo->nFileSizeHigh) << 32;
        CommonUtility::chunk_chks(tChksEntry.szFileChks, hChunk, qwFileSize, ((unsigned __int64)iListPosit) << 22);
        tChksEntry.ftLastWrite = fileInfo->ftLastWriteTime;
        WriteNode(hChksList, &tChksEntry, lListInde);
        // printf("update chks, lListPosit:%u tChksEntry.time_stamp:%ld\n", lListPosit, tChksEntry.time_stamp);
        //
        if(INVALID_HANDLE_VALUE != hChunk) {
            CloseHandle( hChunk );
            hChunk = INVALID_HANDLE_VALUE;
        }
    }
    //
    return lListInde;
}

DWORD ChksUtility::ChunkRiveChks(struct riv_chks *pRiveChks, HANDLE hChksList, ULONG lListPosit)
{
    struct ChksEntry tChksEntry;
    struct riv_chks rchks;
    //
    // _LOG_TRACE(_T("read chks lListPosit:%u"), lListPosit);
    if (INVA_INDE_VALU == ReadNode(hChksList, &tChksEntry, lListPosit))
        return 0x01;
    memcpy(rchks.md5_chks, tChksEntry.szFileChks, MD5_DIGEST_LEN);
    rchks.offset = 0;
    memcpy(pRiveChks, &rchks, sizeof(struct riv_chks));
    //
    return 0x00;
}

ULONG ChksUtility::ChunkWriteUpdate(HANDLE hChksList, ULONG lListHinde, DWORD iListPosit, FILETIME *ftLastWrite)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind;
    //
    if (INVA_INDE_VALU == lListHinde) return INVA_INDE_VALU;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; iListPosit >= ind; ind++) {
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (INVA_INDE_VALU == lListInde) return INVA_INDE_VALU;
    }
    //
    if (memcmp(&tChksEntry.ftLastWrite, ftLastWrite, sizeof(FILETIME))) {
// _LOG_TRACE(_T("update chunk last write. iListPosit:%u"), iListPosit);
        tChksEntry.ftLastWrite = *ftLastWrite;
        WriteNode(hChksList, &tChksEntry, lListInde);
        // printf("update last write, lListPosit:%u tChksEntry.time_stamp:%ld\n", lListPosit, tChksEntry.time_stamp);
    }
    //
    return lListInde;
}

ULONG ChksUtility::ChunkUpdate(HANDLE hChksList, ULONG lListHinde, DWORD iListPosit, unsigned char *md5_chks, FILETIME *ftLastWrite)
{
    struct ChksEntry tChksEntry;
    ULONG lListInde;
    DWORD ind;
    //
    if (INVA_INDE_VALU == lListHinde) return INVA_INDE_VALU;
    tChksEntry.sibling = lListHinde;
    for (ind = 0; iListPosit >= ind; ind++) {
        lListInde = ReadNode(hChksList, &tChksEntry, tChksEntry.sibling);
        if (INVA_INDE_VALU == lListInde) return INVA_INDE_VALU;
    }
    //
// _LOG_TRACE(_T("update chunk last write. iListPosit:%u"), iListPosit);
    memcpy(tChksEntry.szFileChks, md5_chks, MD5_DIGEST_LEN);
    tChksEntry.ftLastWrite = *ftLastWrite;
    WriteNode(hChksList, &tChksEntry, lListInde);
    // printf("update last write, lListPosit:%u tChksEntry.time_stamp:%ld\n", lListPosit, tChksEntry.time_stamp);
    //
    return lListInde;
}