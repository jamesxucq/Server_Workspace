#pragma once

#define CLIENT_CONFIGURATION  _T("Configuration.XML")

// #define BOOL_TEXT_LEN					8
#define MAX_TEXT_LEN					512

#define MKZEO(TEXT) TEXT[0] = _T('\0')

namespace Parser {
	const TCHAR *wcsend(const TCHAR *str);
	TCHAR *ModuleBaseNameEx(TCHAR *lpFilePath);
	int ParseAutoRun(BOOL *bAutoRun, TCHAR *szFileName);
};
