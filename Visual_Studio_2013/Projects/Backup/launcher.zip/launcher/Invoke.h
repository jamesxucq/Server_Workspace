#pragma once



#define APPLICATION_NAME				_T("sdclient")
#define CLIENT_EXECUTE_NAME				_T("sdclient.exe")

namespace Invoke {
	DWORD SingleInstance(TCHAR *szAppName);
	DWORD LaunchProcess(TCHAR *szProgramPath);
	DWORD ExecuteApplica(TCHAR *szApplicaPath);
};
