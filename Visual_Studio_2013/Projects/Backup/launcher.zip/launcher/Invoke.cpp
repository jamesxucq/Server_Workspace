#include "StdAfx.h"

#include "windows.h"
#include "Invoke.h"

DWORD Invoke::SingleInstance(TCHAR *szAppName) {
	HANDLE	hMutex = CreateMutex(NULL, TRUE, szAppName);
	if(ERROR_ALREADY_EXISTS==GetLastError() || NULL==hMutex)
		return ((DWORD)-1);
	CloseHandle(hMutex);
	return 0x00;
}

DWORD Invoke::LaunchProcess(TCHAR *szProgramPath) {
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
//
	memset(&si, 0, sizeof(STARTUPINFO));
	si.cb = sizeof(STARTUPINFO);
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.lpDesktop = _T("WinSta0\\Default");
	si.wShowWindow = SW_SHOW;
	memset(&pi, 0, sizeof(PROCESS_INFORMATION));
//
	// DETACHED_PROCESS
	if(!CreateProcess(szProgramPath,NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)) {
		// _LOG_WARN(_T("CreatProcess failed on error %d"), GetLastError());
		return ((DWORD)-1);
	} else {
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
		// cout<<"NWE PROCESSID:"<<pi.dwProcessId;
		// cout<<"NEW THREADID:"<<pi.dwThreadId;
	}
//
	return 0x00;
}

DWORD Invoke::ExecuteApplica(TCHAR *szApplicaPath) {
	if((int)ShellExecute(NULL, _T("open"), szApplicaPath, NULL, NULL, SW_SHOWNORMAL) <= 32)
		return ((DWORD)-1);
	return 0x00;
}