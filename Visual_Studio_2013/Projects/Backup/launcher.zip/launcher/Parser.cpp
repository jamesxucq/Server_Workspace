#include "StdAfx.h"

#include "windows.h"
#include "Parser.h"

#define s_strlen(str) (sizeof(str) - 1)

#define START_AURU_LABEL        "<AutoRun>"
#define END_AURU_LABEL          "</AutoRun>"

#define GET_ELEMENT_VALUE(ELEMENT_VALUE, PARSE_TOKEN, LABEL_START, LABEL_END) { \
    char *elem_end, *elem_start; \
    if(elem_start = strstr(PARSE_TOKEN, LABEL_START)) { \
        elem_start += s_strlen(LABEL_START); \
        if (elem_end = strstr(elem_start, LABEL_END)) { \
            int length = elem_end - elem_start; \
            strncpy_s(ELEMENT_VALUE, elem_start, length); \
            ELEMENT_VALUE[length] = '\0'; \
            PARSE_TOKEN = elem_end + s_strlen(LABEL_END); \
        } else PARSE_TOKEN = NULL; \
    } else PARSE_TOKEN = NULL; \
}

#define LOAD_BUFF_SIZE					0x1000  // 4K

static char *LoadFile(char *szContent, TCHAR *szFileName, DWORD dwLength) {
	HANDLE hLoadFile;

	hLoadFile = CreateFile( szFileName, 
		GENERIC_READ,
		FILE_SHARE_READ, 
		NULL, 
		OPEN_EXISTING, 
		FILE_ATTRIBUTE_NORMAL, 
		NULL);
	if( INVALID_HANDLE_VALUE == hLoadFile ) {
		// TRACE( _T("create file failed: %d"), GetLastError() );
		OutputDebugString(_T("create file failed."));
		return NULL;
	}
	DWORD dwFileSize = GetFileSize(hLoadFile, NULL);
	if(INVALID_FILE_SIZE==dwFileSize && NO_ERROR!=GetLastError()) {
		CloseHandle(hLoadFile);
		return NULL;
	}
	if(dwLength < dwFileSize) {
		CloseHandle(hLoadFile);
		return NULL;
	}
	DWORD dwResult = SetFilePointer(hLoadFile, 0, NULL, FILE_BEGIN);
	if(INVALID_SET_FILE_POINTER==dwResult && NO_ERROR!=GetLastError()) {
		CloseHandle(hLoadFile);
		return NULL;
	}
//
	DWORD dwReadSize = 0x00;
	if(!ReadFile(hLoadFile, szContent, dwFileSize, &dwReadSize, NULL) || dwFileSize!=dwReadSize) {
		CloseHandle(hLoadFile);
		return NULL;
	}
	szContent[dwReadSize] = '\0';
//
	CloseHandle(hLoadFile);
	return szContent;
}

int Parser::ParseAutoRun(BOOL *bAutoRun, TCHAR *szFileName) {
	char szContentXml[LOAD_BUFF_SIZE];
	if(!LoadFile(szContentXml, szFileName, LOAD_BUFF_SIZE))
		return -1;
	//
	char element_value[MAX_TEXT_LEN];
	char *parse_toke = szContentXml;
	GET_ELEMENT_VALUE(element_value, parse_toke, START_AURU_LABEL, END_AURU_LABEL);
	if(parse_toke) {
		if(!_stricmp("true", element_value)) *bAutoRun = TRUE;
		else if(!_stricmp("false", element_value)) *bAutoRun = FALSE;
		else *bAutoRun = FALSE;
	} else *bAutoRun = FALSE;
	//
	return 0;
}

TCHAR *Parser::ModuleBaseNameEx(TCHAR *lpFilePath) {
    TCHAR szDirePath[MAX_PATH];
    if(!lpFilePath) return NULL;
    //
    if (!GetModuleFileName(NULL, szDirePath, MAX_PATH)) return NULL;
	TCHAR *Token = _tcsrchr(szDirePath, _T('\\'));
	if (!Token) return NULL;
	*(++Token) = _T('\0');
    _tcscpy_s(lpFilePath, MAX_PATH, szDirePath);
    //
    return lpFilePath;
}

const TCHAR *Parser::wcsend(const TCHAR *str) {
	const TCHAR *char_ptr;
	const unsigned long int *longword_ptr;
	unsigned long int longword, himagic, lomagic;
//
	for (char_ptr = str; ((unsigned long int) char_ptr & (sizeof (longword) - 1)) != 0; ++char_ptr) {
		if (*char_ptr == '\0')
			return (char_ptr);
	}
//
	longword_ptr = (unsigned long int *) char_ptr;
	himagic = 0x80008000L;
	lomagic = 0x01000100L;
	if (sizeof (longword) > 4) {
		himagic = ((himagic << 16) << 16) | himagic;
		lomagic = ((lomagic << 16) << 16) | lomagic;
	}
	if (sizeof (longword) > 8) abort ();
//
	for (;;) {
		longword = *longword_ptr++;
		if (((longword - lomagic) & ~longword & himagic) != 0)
		{
			const TCHAR *cp = (const TCHAR *) (longword_ptr - 1);
			//
			if (cp[0] == 0)
				return (cp);
			if (cp[1] == 0)
				return (cp + 1);

			if (sizeof (longword) > 4)
			{
				if (cp[2] == 0)
					return (cp + 2);
				if (cp[3] == 0)
					return (cp + 3);
			}
		}
	}
}