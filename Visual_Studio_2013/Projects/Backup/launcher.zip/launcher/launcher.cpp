// launcher.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <windows.h>
#include "Invoke.h"
#include "Parser.h"


void LogEvent(LPCTSTR pszFormat, ...);
void WINAPI ServiceMain(int argc, _TCHAR* argv[]);
void WINAPI ServerCtrlHandler(DWORD Control);
void LogEvent(LPCTSTR pszFormat, ...);
int ServiceSpecific(int argc, _TCHAR* argv[]);

TCHAR ServiceName[] = _T("launcher");
SERVICE_STATUS_HANDLE hServiceStatus;
SERVICE_STATUS status;

int _tmain(int argc, _TCHAR* argv[]) {
	SERVICE_TABLE_ENTRY DispatchTable[] = {
		{ ServiceName, (LPSERVICE_MAIN_FUNCTION)ServiceMain },
		{ NULL, NULL }
	};
	//
	if (!StartServiceCtrlDispatcher(DispatchTable)) {
		LogEvent(_T("Register Service Main Function Error!"));
	}
	//
	return 0;
}

void WINAPI ServiceMain(int argc, _TCHAR* argv[]) {
    // Register the control request handler
    status.dwServiceType = SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS;
    status.dwCurrentState = SERVICE_START_PENDING;
    status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
    status.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
    status.dwServiceSpecificExitCode = 0;
    status.dwCheckPoint = 0;
    status.dwWaitHint = 0;
 
    //ע��������
    hServiceStatus = RegisterServiceCtrlHandler(ServiceName, ServerCtrlHandler);
    if (hServiceStatus == NULL) {
		status.dwCurrentState = SERVICE_STOPPED;
		status.dwServiceSpecificExitCode = 1;
		SetServiceStatus(hServiceStatus, &status);
        LogEvent(_T("Handler not installed"));
        return;
    }
    SetServiceStatus(hServiceStatus, &status);
 
    status.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
    status.dwCheckPoint = 0;
    status.dwWaitHint = 0;
    status.dwCurrentState = SERVICE_RUNNING;
    SetServiceStatus(hServiceStatus, &status);
 
    //ģ����������.Ӧ��ʱ����Ҫ������ڴ˼���
	if(ServiceSpecific(argc, argv)) {
		status.dwCurrentState = SERVICE_STOPPED;
		status.dwServiceSpecificExitCode = 1;
		SetServiceStatus(hServiceStatus, &status);
		return;
	}
    status.dwCurrentState = SERVICE_STOPPED;
    SetServiceStatus(hServiceStatus, &status);
    OutputDebugString(_T("Service stopped"));
}

// int _tmain(int argc, _TCHAR* argv[]) {
int ServiceSpecific(int argc, _TCHAR* argv[]) {
	// Load location config
	TCHAR szFilePath[MAX_PATH];
	MKZEO(szFilePath);
	if(!Parser::ModuleBaseNameEx(szFilePath)) return -1;
	TCHAR *tokep = (TCHAR *)Parser::wcsend(szFilePath);
	//
	_tcscpy_s(tokep, MAX_PATH-((tokep-szFilePath)>>0x01), CLIENT_CONFIGURATION);
	BOOL bAutoRun = FALSE;
	if(Parser::ParseAutoRun(&bAutoRun, szFilePath))
		return -1;
	//
	DWORD dwLaunAppl = Invoke::SingleInstance(APPLICATION_NAME);
	if(!dwLaunAppl && bAutoRun) {
		_tcscpy_s(tokep, MAX_PATH-((tokep-szFilePath)>>0x01), CLIENT_EXECUTE_NAME);
		// Invoke::ExecuteApplica(szFilePath);
		Invoke::LaunchProcess(szFilePath);
	}
	// success
	return 0;
}

void WINAPI ServerCtrlHandler(DWORD Control) {
    switch (Control) {
    case SERVICE_CONTROL_STOP:
        // status.dwCurrentState = SERVICE_STOP_PENDING;
        // SetServiceStatus(hServiceStatus, &status);
        break;
    case SERVICE_CONTROL_PAUSE:
        break;
    case SERVICE_CONTROL_CONTINUE:
        break;
    case SERVICE_CONTROL_INTERROGATE:
        break;
    case SERVICE_CONTROL_SHUTDOWN:
        break;
    default:
        LogEvent(_T("Bad service request"));
        OutputDebugString(_T("Bad service request"));
    }
}

void LogEvent(LPCTSTR pFormat, ...) {
	TCHAR chMsg[256];
	HANDLE hEventSource;
	LPTSTR lpszStrings[1];
	va_list pArg;

	va_start(pArg, pFormat);
	_vstprintf_s(chMsg, pFormat, pArg);
	va_end(pArg);

	lpszStrings[0] = chMsg;

	hEventSource = RegisterEventSource(NULL, ServiceName);
	if (hEventSource != NULL) {
		ReportEvent(hEventSource, EVENTLOG_INFORMATION_TYPE, 0, 0, NULL, 1, 0, (LPCTSTR*) &lpszStrings[0], NULL);
		DeregisterEventSource(hEventSource);
	}
}
